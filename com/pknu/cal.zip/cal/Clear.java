package com.pknu.cal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class Clear implements ActionListener {
	JTextField valueField;
	
	public Clear(JTextField valueField) {
		this.valueField = valueField;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		CalDesign.first="";
		CalDesign.second="";
		CalDesign.operator="";
		valueField.setText("");
	}

}
