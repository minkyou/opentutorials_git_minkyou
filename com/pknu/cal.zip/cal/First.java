package com.pknu.cal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class First implements ActionListener {
	JTextField valueField;
	
	public First(JTextField valueField) {
		this.valueField = valueField;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(CalDesign.st.size() < 2) {
			CalDesign.first += e.getActionCommand();
			valueField.setText(CalDesign.first);
		} 
		else {
			CalDesign.second += e.getActionCommand();
			valueField.setText(CalDesign.first+CalDesign.operator+CalDesign.second);
		}
		
		
		
//		CalDesign.st.push(item)
		System.out.println();
	}

}
