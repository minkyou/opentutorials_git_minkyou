package com.pknu.cal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class Equal implements ActionListener {

	JTextField valueField;
	
	String firstResult, secondResult, operResult;
	int x, y;
	int result;
	
	public Equal(JTextField valueField) {
		this.valueField = valueField;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		//CalDesign.operEqual = e.getActionCommand();
		valueField.setText(CalDesign.first+CalDesign.operator+CalDesign.second+"=");
		CalDesign.st.push(CalDesign.second);
		
		y=Integer.parseInt(CalDesign.st.pop());
		operResult=CalDesign.st.pop();
		x=Integer.parseInt(CalDesign.st.pop());
		
		if(operResult.equals("+")) {
			result=x+y;
		} else if(operResult.equals("-")) {
			result=x-y;
		} else if(operResult.equals("*")) {
			result=x*y;
		}  else if(operResult.equals("/")) {
			result=x/y;
		}
		
		valueField.setText(CalDesign.first+CalDesign.operator+CalDesign.second+"="+result);
	}

}
