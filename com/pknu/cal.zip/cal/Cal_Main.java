package com.pknu.cal;

public class Cal_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CalDesign cd = new CalDesign("����");
		cd.setBounds(300, 300, 300, 300);
		cd.setVisible(true);
	}

}
