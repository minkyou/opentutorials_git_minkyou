package com.pknu.cal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class Operator implements ActionListener {

	JTextField valueField;
	
	public Operator(JTextField valueField) {
		this.valueField = valueField;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		CalDesign.operator = e.getActionCommand();
		valueField.setText(CalDesign.first+CalDesign.operator);
		CalDesign.st.push(CalDesign.first);
		CalDesign.st.push(CalDesign.operator);
	}

}
