package com.pknu.db;

public class Test {
	public static void main(String[] args) {
//		SingletonTest st = new SingletonTest();		// not visiable
		
		
	}
}
 